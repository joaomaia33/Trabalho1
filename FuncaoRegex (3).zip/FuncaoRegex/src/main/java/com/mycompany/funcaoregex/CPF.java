/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcaoregex;

/**
 *
 * @author João Vitor Maia Lippi
 */
public class CPF {
    private String cpf;

    // Construtor da classe CPF
    public CPF(String cpf) {
        this.cpf = cpf;
    }

    // Função para remover traços e pontos do CPF
    public String removerPontos() {
        return cpf.replaceAll("[.-]", "");
    }
}
