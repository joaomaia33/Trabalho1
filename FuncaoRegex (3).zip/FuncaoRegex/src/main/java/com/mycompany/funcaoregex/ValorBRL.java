/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcaoregex;

/**
 *
 * @author João Vitor Maia Lippi
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValorBRL {
    private String valor;

    // Construtor da classe ValorBRL
    public ValorBRL(String valor) {
        this.valor = valor;
    }

    // Função para validar um valor em BRL
    public boolean validar() {
        String regex = "^(R\\$|r\\$)\\s?\\d{1,3}(\\.\\d{3})*(,\\d{2})?$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(valor);
        return matcher.matches();
    }
}
