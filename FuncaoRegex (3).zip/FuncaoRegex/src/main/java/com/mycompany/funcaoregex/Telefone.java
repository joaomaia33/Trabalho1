/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcaoregex;

/**
 *
 * @author João Vitor Maia Lippi
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Telefone {
    private String telefone;

    // Construtor da classe Telefone
    public Telefone(String telefone) {
        this.telefone = telefone;
    }

    // Função para validar um número de telefone
    public boolean validar() {
        String regex = "^\\(\\d{2}\\)\\s?\\d{4,5}[-\\s]?\\d{4}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(telefone);
        return matcher.matches();
    }
}

